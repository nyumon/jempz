<?php

	define("DB_HOST"	, "mysql.idhostinger.com");
	define("DB_USER"	, "u876493553_root");
	define("DB_PASSWORD", "qwerty123");
	define("DB_NAME"	, "u876493553_new");

?>