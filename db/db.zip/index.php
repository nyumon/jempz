<?php 
	
	require_once "include/connect.php";

	$db = new DB_connect();

?>